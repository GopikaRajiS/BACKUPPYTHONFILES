from django.apps import AppConfig


class ApisConfig(AppConfig):
    name = 'apis'
